<template>
  <section id="features" class="py-16 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <!-- Section Title -->
      <div class="text-center mb-12">
        <h2 class="text-4xl font-bold text-gray-800">What We Offer</h2>
        <p class="text-lg text-gray-600 mt-2">Powerful tools to streamline and simplify property management</p>
      </div>

      <!-- Features Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <!-- Feature 1 -->
        <div class="border rounded-lg p-6 shadow hover:shadow-xl transition duration-300">
          <div class="flex items-center justify-center w-14 h-14 bg-orange-100 rounded-full mb-4">
            <i class="fas fa-building text-orange-500 text-2xl"></i>
          </div>
          <h3 class="text-xl font-semibold text-gray-800 mb-2">Property Management</h3>
          <p class="text-gray-600">
            Easily manage multiple properties, units, and facilities from a single intuitive dashboard.
          </p>
        </div>

        <!-- Feature 2 -->
        <div class="border rounded-lg p-6 shadow hover:shadow-xl transition duration-300">
          <div class="flex items-center justify-center w-14 h-14 bg-orange-100 rounded-full mb-4">
            <i class="fas fa-handshake text-orange-500 text-2xl"></i>
          </div>
          <h3 class="text-xl font-semibold text-gray-800 mb-2">Sales Management</h3>
          <p class="text-gray-600">
            Track and manage property sales, leads, and commissions with real-time insights and reports.
          </p>
        </div>

        <!-- Feature 3 -->
        <div class="border rounded-lg p-6 shadow hover:shadow-xl transition duration-300">
          <div class="flex items-center justify-center w-14 h-14 bg-orange-100 rounded-full mb-4">
            <i class="fas fa-key text-orange-500 text-2xl"></i>
          </div>
          <h3 class="text-xl font-semibold text-gray-800 mb-2">Rental Management</h3>
          <p class="text-gray-600">
            Automate rent collection, lease tracking, and tenant communication all in one place.
          </p>
        </div>

        <!-- Feature 4 -->
        <div class="border rounded-lg p-6 shadow hover:shadow-xl transition duration-300">
          <div class="flex items-center justify-center w-14 h-14 bg-orange-100 rounded-full mb-4">
            <i class="fas fa-chart-line text-orange-500 text-2xl"></i>
          </div>
          <h3 class="text-xl font-semibold text-gray-800 mb-2">Real-Time Analytics</h3>
          <p class="text-gray-600">
            Monitor performance with smart analytics and financial dashboards tailored to your portfolio.
          </p>
        </div>

        <!-- Feature 5 -->
        <div class="border rounded-lg p-6 shadow hover:shadow-xl transition duration-300">
          <div class="flex items-center justify-center w-14 h-14 bg-orange-100 rounded-full mb-4">
            <i class="fas fa-user-shield text-orange-500 text-2xl"></i>
          </div>
          <h3 class="text-xl font-semibold text-gray-800 mb-2">Tenant Portal</h3>
          <p class="text-gray-600">
            Give tenants access to a personalized portal for maintenance requests, rent payments, and more.
          </p>
        </div>

        <!-- Feature 6 -->
        <div class="border rounded-lg p-6 shadow hover:shadow-xl transition duration-300">
          <div class="flex items-center justify-center w-14 h-14 bg-orange-100 rounded-full mb-4">
            <i class="fas fa-mobile-alt text-orange-500 text-2xl"></i>
          </div>
          <h3 class="text-xl font-semibold text-gray-800 mb-2">Mobile Access</h3>
          <p class="text-gray-600">
            Access your PMS system from anywhere using mobile-friendly dashboards and tools.
          </p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>
