<template>
  <header class="bg-gray-200 p-4 rounded shadow">
    <h2 class="text-xl font-semibold">App Header</h2>
  </header>
</template>

<script>
export default {
  name: "CommonHeader"
}
</script>

<style scoped>
</style>
